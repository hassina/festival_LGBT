
jQuery(document).ready(function() {
	jQuery(".slideshow").responsiveSlides();
});

